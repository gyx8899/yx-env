console.log(process.argv);
console.log(process.env.arg1);
console.log(process.env.arg2);
console.log(process.env.argn);

const yargs = require("yargs");
console.log(yargs.argv);
